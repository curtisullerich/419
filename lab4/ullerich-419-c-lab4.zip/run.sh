hadoop jar Cluster.jar Cluster "/datasets/Lab4/group-files" "01"
